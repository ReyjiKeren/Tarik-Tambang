class NetworkManager {
    constructor() {
        this.peer = null;
        this.channel = null;
        this.isHost = false;

        // Public STUN servers
        this.config = {
            iceServers: [
                { urls: 'stun:stun.l.google.com:19302' },
                { urls: 'stun:stun1.l.google.com:19302' }
            ]
        };

        this.onConnect = null; // Callback
        this.onData = null; // Callback for game data
    }

    async init(mode) {
        this.isHost = (mode === 'host');
        this.peer = new RTCPeerConnection(this.config);

        this.peer.onicecandidate = async (e) => {
            if (e.candidate === null) {
                // Gathering done, ready to share localDescription
                // We use async/await here, so we wrap it
                try {
                    const code = await this.encodeSignal(this.peer.localDescription);
                    document.dispatchEvent(new CustomEvent('signal-ready', { detail: code }));
                } catch (err) {
                    console.error("Compression Failed", err);
                }
            }
        };

        this.peer.onconnectionstatechange = () => {
            console.log('Connection State:', this.peer.connectionState);
            if (this.peer.connectionState === 'connected') {
                if (this.onConnect) this.onConnect();
            }
        };

        if (this.isHost) {
            this.channel = this.peer.createDataChannel("game");
            this.setupChannel(this.channel);

            try {
                const offer = await this.peer.createOffer();
                await this.peer.setLocalDescription(offer);
            } catch (err) {
                console.error("Offer Creation Failed", err);
            }
        } else {
            this.peer.ondatachannel = (e) => {
                this.channel = e.channel;
                this.setupChannel(this.channel);
            };
        }
    }

    setupChannel(chan) {
        chan.onopen = () => console.log("DataChannel Open");
        chan.onmessage = (e) => {
            if (this.onData) this.onData(JSON.parse(e.data));
        };
    }

    // Process the code pasted by user
    async handleSignal(codeStr) {
        try {
            const signal = await this.decodeSignal(codeStr);
            console.log("Received Signal Type:", signal.type);

            if (this.isHost) {
                // Host receives Answer
                if (signal.type === 'answer') {
                    await this.peer.setRemoteDescription(signal);
                }
            } else {
                // Client receives Offer
                if (signal.type === 'offer') {
                    await this.peer.setRemoteDescription(signal);

                    const answer = await this.peer.createAnswer();
                    await this.peer.setLocalDescription(answer);
                    // note: onicecandidate will trigger automatically to send Answer
                }
            }
        } catch (e) {
            console.error("Invalid Code", e);
            alert("Invalid Code! Make sure you copied the entire block.");
        }
    }

    send(data) {
        if (this.channel && this.channel.readyState === 'open') {
            this.channel.send(JSON.stringify(data));
        }
    }

    // --- Compression Logic (Async) ---

    async encodeSignal(signal) {
        const jsonStr = JSON.stringify(signal);

        // Use browser GZIP CompressionStream
        // 1. Convert String -> Uint8Array
        const enc = new TextEncoder();
        const encodedData = enc.encode(jsonStr);

        // 2. Compress via stream
        const stream = new Blob([encodedData]).stream();
        const compressedStream = stream.pipeThrough(new CompressionStream("gzip"));
        const response = await new Response(compressedStream);
        const blob = await response.blob();

        // 3. Convert Blob -> Base64
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onloadend = () => {
                // reader.result is "data:application/octet-stream;base64,....."
                // Split to get just base64
                const base64 = reader.result.split(',')[1];
                resolve(base64);
            };
            reader.onerror = reject;
            reader.readAsDataURL(blob);
        });
    }

    async decodeSignal(base64Str) {
        // 1. Base64 -> Blob (via fetch or byte array)
        // Easiest is to hydrate a data URI
        const res = await fetch(`data:application/octet-stream;base64,${base64Str}`);
        const blob = await res.blob();

        // 2. Decompress
        const stream = blob.stream();
        const decompressedStream = stream.pipeThrough(new DecompressionStream("gzip"));
        const response = await new Response(decompressedStream);

        // 3. Blob -> JSON
        const text = await response.text();
        return JSON.parse(text);
    }
}

window.Network = new NetworkManager();
